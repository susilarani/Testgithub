/**
 * Created by Acer on 06/01/2017.
 */
public class Sample {
    public static void main(String args[]){
        int a=7;
        int b=8;
        float c=4.3f;
        char m='s';
        String n="Welcome";
        System.out.println(a+" "+b);
        System.out.println(c);
        System.out.println(m);
        System.out.println(n);
    }
}

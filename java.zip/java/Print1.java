/**
 * Created by Acer on 06/01/2017.
 */
public class Print1 {
    public static void main(String args[]) {
        int i = 0;
        while (i < 5) {
            i++;
            System.out.println("Welcome");
        }

    }
}

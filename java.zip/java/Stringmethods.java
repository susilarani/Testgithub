/**
 * Created by Acer on 06/01/2017.
 */
public class Stringmethods {
    public static void main(String args[]){
        String m1="Sample";
        String m2="Sample";
        System.out.println(m1.length());
        System.out.println(m1.toUpperCase());
        System.out.println(m1.toLowerCase());
        System.out.println(m1.substring(0,5));
        System.out.println(m1.replace('a','s'));
        System.out.println(m1.charAt(3));
        System.out.println(m1.equals(m2));
        System.out.println(m1.compareTo(m2));


    }
}

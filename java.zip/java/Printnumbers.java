/**
 * Created by Acer on 06/01/2017.
 */
public class Printnumbers {
    public static void main(String args[]){
        int i=0;
        for (i=0;i<100;i++){
            System.out.println(i);
        }
    }
}

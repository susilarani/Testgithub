/**
 * Created by Acer on 06/01/2017.
 */
public class Comparison {
  static   int a=100;
    public static void main(String args[]){
        if (a%2==0)
            System.out.println("Even");
        else {
            System.out.println("Odd");
        }
    }

}

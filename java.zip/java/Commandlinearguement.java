/**
 * Created by Acer on 06/01/2017.
 */
public class Commandlinearguement {
    public static void main(String a[]){

        System.out.println(a[0]);
    }
}

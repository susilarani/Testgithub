/**
 * Created by Acer on 06/01/2017.
 */
public class Staticmethod {
    public static void add() {
        int a = 5;
        System.out.println(a++);
    }
    public static void main(String args[]){
        add();
        add();

    }
}

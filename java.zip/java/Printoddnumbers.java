/**
 * Created by Acer on 06/01/2017.
 */
public class Printoddnumbers {
    public static void main(String args[]) {
        int i;
        for (i = 1; i <= 100; i++) {
            if (i % 2 == 1) {
                System.out.println(i);
            }
        }
    }
}
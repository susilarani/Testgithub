/**
 * Created by Acer on 06/01/2017.
 */
public class Conditionalstatements {
    public static void main(String args[]){

    int age=60;
    int a=7;
    int b=6;
    int c=9;
    if(age>18)
        System.out.println("Major");
    else {
        System.out.println("Minor");
        }
        if (a>c)
            System.out.println("False");
    else if (b>c)
        System.out.println("True");
    else {
        System.out.println("Welcome");
        }






    }
}

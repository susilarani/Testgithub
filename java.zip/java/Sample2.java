/**
 * Created by Acer on 06/01/2017.
 */
public class Sample2 {
    public static void main(String args[]){
        System.out.println("hai"+2+3);
        System.out.println(2+3+"hai");
    }
}

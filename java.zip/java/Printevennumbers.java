/**
 * Created by Acer on 06/01/2017.
 */
public class Printevennumbers {
    public static void main(String args[]) {
        int i;
        for (i = 1; i <= 100; i++) {
            if (i % 2 == 0) {
                System.out.println(i);
            }
        }
    }
}

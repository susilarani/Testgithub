/**
 * Created by Acer on 06/01/2017.
 */
public class Print {
    public static void main(String args[]){
        int i=0;
        for (i=0;i<10;i++){
            System.out.print("Sample");


        }

    }

}

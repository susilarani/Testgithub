/**
 * Created by Acer on 06/01/2017.
 */
public class Print2 {
    public static void main(String args[]){
        int i=8;
        do {
            System.out.println("Welcome");
            i++;
        }
            while (i<5);

        }
    }

